import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShieldCheck, Lock, Unlock } from "lucide-react"
import EncryptForm from "@/components/encrypt-form"
import DecryptForm from "@/components/decrypt-form"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 sm:p-8 md:p-12 bg-background text-foreground">
      <div className="w-full max-w-2xl mx-auto">
        <header className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-primary/10 text-primary p-3 rounded-full mb-4">
            <ShieldCheck className="h-10 w-10" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold font-headline text-foreground">
            TXT Vault
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">
            Your personal secure text vault.
          </p>
        </header>

        <Tabs defaultValue="encrypt" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="encrypt">
              <Lock className="mr-2 h-4 w-4" />
              Encrypt
            </TabsTrigger>
            <TabsTrigger value="decrypt">
              <Unlock className="mr-2 h-4 w-4" />
              Decrypt
            </TabsTrigger>
          </TabsList>
          <TabsContent value="encrypt">
            <EncryptForm />
          </TabsContent>
          <TabsContent value="decrypt">
            <DecryptForm />
          </TabsContent>
        </Tabs>
        <footer className="text-center mt-12 text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} TXT Vault. All rights reserved.</p>
        </footer>
      </div>
    </main>
  )
}
