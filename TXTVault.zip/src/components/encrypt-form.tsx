'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { encryptText } from '@/lib/crypto';
import { Loader2 } from 'lucide-react';
import { db } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';

const formSchema = z.object({
  identifier: z.string().min(1, 'Identifier is required.'),
  passphrase: z.string().min(8, 'Passphrase must be at least 8 characters.'),
  text: z.string().min(1, 'Text to encrypt is required.'),
});

export default function EncryptForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      identifier: '',
      passphrase: '',
      text: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    try {
      const { encryptedData, salt, iv } = await encryptText(values.text, values.passphrase);
      const dataToStore = { encryptedData, salt, iv };
      
      await setDoc(doc(db, "vault", values.identifier), dataToStore);

      toast({
        title: 'Success!',
        description: 'Your text has been encrypted and stored securely.',
      });
      form.reset();
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Storage Failed',
        description: 'Could not save data. Please check your Firebase setup and network connection.',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Encrypt & Store</CardTitle>
        <CardDescription>Enter a unique identifier, a strong passphrase, and the text you want to secure.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="identifier"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Identifier</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., my-secret-api-key" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="passphrase"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Passphrase</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Your secret passphrase" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="text"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Text to Encrypt</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Paste your sensitive text here..." className="min-h-[150px] resize-y" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Encrypt & Save
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
