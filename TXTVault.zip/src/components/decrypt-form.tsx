'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { decryptText } from '@/lib/crypto';
import { Loader2, Copy, Check } from 'lucide-react';
import { db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

const formSchema = z.object({
  identifier: z.string().min(1, 'Identifier is required.'),
  passphrase: z.string().min(1, 'Passphrase is required.'),
});

export default function DecryptForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [decryptedTextValue, setDecryptedTextValue] = useState<string | null>(null);
  const [hasCopied, setHasCopied] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      identifier: '',
      passphrase: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);
    setDecryptedTextValue(null);
    setHasCopied(false);

    try {
      const docRef = doc(db, "vault", values.identifier);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('No data found for this identifier.');
      }

      const storedData = docSnap.data();
      if (!storedData.encryptedData || !storedData.salt || !storedData.iv) {
        throw new Error('Stored data is corrupted or in an invalid format.');
      }
      
      const { encryptedData, salt, iv } = storedData;
      const text = await decryptText(encryptedData, values.passphrase, salt, iv);
      setDecryptedTextValue(text);
      form.reset({ ...values, passphrase: '' });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Decryption Failed',
        description: error instanceof Error ? error.message : 'An unknown error occurred.',
      });
      setDecryptedTextValue(null);
    } finally {
      setIsSubmitting(false);
    }
  }
  
  const handleCopy = () => {
    if (decryptedTextValue) {
      navigator.clipboard.writeText(decryptedTextValue);
      setHasCopied(true);
      toast({ title: 'Copied to clipboard!' });
      setTimeout(() => setHasCopied(false), 2000);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Retrieve & Decrypt</CardTitle>
        <CardDescription>Enter the identifier and passphrase to retrieve your secure text.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="identifier"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Identifier</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., my-secret-api-key" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="passphrase"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Passphrase</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Your secret passphrase" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Retrieve & Decrypt
            </Button>
          </form>
        </Form>
      </CardContent>
      {decryptedTextValue !== null && (
        <CardFooter className="flex-col items-start gap-4 pt-6">
            <div className="w-full space-y-2">
                <h3 className="font-semibold">Decrypted Text:</h3>
                <div className="relative rounded-md border bg-muted p-4 pr-12 min-h-[100px]">
                    <pre className="whitespace-pre-wrap break-words font-sans text-sm">{decryptedTextValue}</pre>
                     <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-8 w-8" onClick={handleCopy}>
                        {hasCopied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                     </Button>
                </div>
            </div>
        </CardFooter>
      )}
    </Card>
  );
}
